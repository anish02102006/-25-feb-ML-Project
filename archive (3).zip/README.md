# 📊 Raw Sales Dataset for RFM \& Customer Segmentation Practice (30,000 Transactions)



🔰🔰🔰🔰🔰



##### Overview



This dataset contains 30,000 raw sales transactions from a retail business across:



100 customers



5 regions



Multiple product categories



🔰🔰🔰🔰🔰



##### ⚠️ Important:



This is a raw transactional dataset. It is intentionally not cleaned or aggregated.





It is designed for learners to practice the complete Data Analytics process:



Data Cleaning



Data Transformation



RFM Metric Construction



Customer Segmentation



Business Insight Development





🔰🔰🔰🔰🔰





##### **Learning Objective**



This dataset is ideal for practicing:





Data Cleaning \& Validation



Data Transformation



Feature Engineering



RFM Analysis (Recency, Frequency, Monetary)



Customer Segmentation



Business Analytics Thinking





Learners must transform transactional-level data into customer-level aggregated metrics before performing segmentation.



🔰🔰🔰🔰🔰



##### Business Scenario



A retail company wants to:





Identify high-value customers



Detect loyal customers



Identify at-risk customers



Improve retention strategy



Support targeted marketing campaigns





However, the available data is raw and transactional, not yet structured into RFM metrics.



Your task is to convert raw data into meaningful business insights.



🔰🔰🔰🔰🔰



##### Dataset Structure (Raw Transaction-Level Data)



**Column			Description**



Transaction\_ID		Sales transaction ID

Customer\_ID		Unique customer identifier

Region			Customer region (5 regions)

Date			Transaction date (raw format)

Product\_ID		Product code

Product\_Name		Product name

Product\_Category	Category

Quantity		Units purchased

PPU			Price per unit

Amount			Transaction total amount





***🔹 Important Notes (Raw Data Characteristics)***



This dataset may contain:



Inconsistent date formats

Possible duplicate records

Potential missing values

Amount values that require validation (Amount ≠ Quantity × PPU)

Inconsistent text formatting

Outliers

Region naming inconsistencies





***Learners are expected to:***



✔ Validate data integrity

✔ Perform cleaning and transformation

✔ Standardize formats

✔ Engineer RFM features

✔ Document assumptions



This reflects real-world business data conditions.



🔰🔰🔰🔰🔰



##### Designed For Educational Practice



This dataset is published intentionally as raw data to simulate real business environments where:



Data is messy



Assumptions must be validated



Cleaning is required before analysis



It encourages responsible and structured analytics practice.



🔰🔰🔰🔰🔰

🔰🔰🔰🔰🔰

🔰🔰🔰🔰🔰

